# /mba-commander-init — MBA Commander Session Orientation

You are invoking the **MBA Commander initialization protocol**. This is an abbreviated
(clarescence)^3 that orients you at the start of every session.

## When to Use

Invoke at the **beginning of every Commander session on MBA**. This is the first thing you
do after `cd ~/Desktop/syncrescendence`.

---

## Step 1: Ground Truth (15 seconds)

Run these commands and absorb the output silently (do NOT dump raw output to user):

```bash
cd ~/Desktop/syncrescendence
git status --short | head -10
git log --oneline -5
```

Note: branch, fingerprint (HEAD hash), uncommitted file count, last 5 commits.

## Step 2: Inbox Scan (15 seconds)

```bash
ls agents/commander/inbox/pending/ 2>/dev/null
```

Count: TASK-* files (actionable), RESULT-* files (dispatch returns), CONFIRM-* files (acknowledgments).
If RESULT/CONFIRM files exist, triage them (read Status field, note agent, archive to RECEIPTS after reading).

## Step 3: Fleet Health (10 seconds)

```bash
launchctl list | grep syncrescendence
```

Count running services. Flag any with non-zero exit codes. Expected on MBA:
- watch-commander (PID, running)
- watch-ajna (PID, running)
- watch-canon (PID, running)
- skill-sync (on-demand via WatchPaths)
- git-sync (on-demand)

Note: watch-psyche on MBA should be DISABLED (Psyche processes on Mac mini only).
Note: watch-adjudicator and watch-cartographer may be stopped on MBA (they run primarily on Mac mini).

## Step 4: Recent Events (10 seconds)

Read the last 10 lines of `00-ORCHESTRATION/state/DYN-GLOBAL_LEDGER.md` to understand
what happened since last session.

## Step 5: Active Intentions (10 seconds)

Read `00-ORCHESTRATION/state/ARCH-INTENTION_COMPASS.md` §URGENT section only.
Note P0 intentions and their status.

## Step 6: Agent Role Check (5 seconds)

Read `BRIDGE.md` §The Constellation — note any status changes (hibernated, reactivated, etc.)

## Step 7: Situation Report

Produce a concise situation report (15-20 lines max):

```
SITREP: MBA Commander | [date] | [fingerprint]
Branch: [branch] | Uncommitted: [count] files
Inbox: [TASK count] pending | [RESULT count] returns | [CONFIRM count] acks
Fleet: [running count]/[expected] services | [flags]
Recent: [1-2 sentence summary of last ledger entries]
P0: [active P0 intentions, 1 line each]
Agents: [1-line status per active agent]
Health: [score]/10
Action: [what to do first]
```

---

## What This Is NOT

This is an **abbreviated orientation**, not a full clarescence. Do NOT:
- Run a full lens sweep (18 lenses)
- Check CANON coherence
- Audit SaaS integrations
- Assess omni-qualities
- Produce a clarescence record file

If the situation requires deeper analysis, recommend invoking `/claresce` after init.

---

## Anti-Patterns

- Do NOT dump raw command output to the user — synthesize into the SITREP
- Do NOT start work before completing the SITREP — orient first, then execute
- Do NOT skip the inbox scan — unprocessed dispatch results are the #1 source of lost work
- Do NOT assume agent states from memory — verify with launchctl + inbox scan
